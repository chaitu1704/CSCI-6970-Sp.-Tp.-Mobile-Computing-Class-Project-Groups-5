//
//  IMDbWebsiteViewController.swift
//  IMDB Search
//
//  Created by Ajay Saradhi Reddy Chilukuri on 3/19/20.
//  Copyright © 2020 Ajay Saradhi Reddy Chilukuri. All rights reserved.
//

import UIKit
import WebKit

class IMDbWebsiteViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setup()
    }
    
    private func setup(){
        if let url = URL(string: "https://www.imdb.com/") {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
}

//
//  IMDbResultViewController.swift
//  IMDB Search
//
//  Created by Ajay Saradhi Reddy Chilukuri on 3/19/20.
//  Copyright © 2020 Ajay Saradhi Reddy Chilukuri. All rights reserved.
//

import UIKit

class IMDbResultViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func openWebsite(_ sender: Any) {
        self.performSegue(withIdentifier: "web", sender: nil)
    }
    
    
}
